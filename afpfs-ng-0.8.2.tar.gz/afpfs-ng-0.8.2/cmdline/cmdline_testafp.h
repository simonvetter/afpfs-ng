#ifndef __CMDLINE_TESTAFP_H_
int test_urls(char *);
#endif

