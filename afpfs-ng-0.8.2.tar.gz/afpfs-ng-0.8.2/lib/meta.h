#ifndef _META_H_
#define _META_H_

struct query_geticon {
	unsigned int filecreator;
	unsigned int filetype;
	unsigned char icontype;
	unsigned short length;
};

#endif
