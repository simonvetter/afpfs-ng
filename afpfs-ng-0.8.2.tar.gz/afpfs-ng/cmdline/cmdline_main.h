
#ifndef __CMDLINE_MAIN_H_
#define __CMDLINE_MAIN_H_

void trigger_connected(void);
void cmdline_forced_ending_hook(void);
void cmdline_loop_started(void);


#endif

