#ifndef __FUSE_INT_H_
#define __FUSE_INT_H_



int afp_register_fuse(int fuseargc, char *fuseargv[],struct afp_volume * vol);
#endif

