#ifndef __COMMANDS_H_
#define __COMMANDS_H_

int fuse_register_afpclient(void);
void fuse_set_log_method(int new_method);

#endif
